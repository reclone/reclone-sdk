// tinyclr - 
// The arm compiler require us to have Graphics_Jpeg.obj in order to build Graphics_Jpeg.lib
// And to get the .obj file, we use this empty dummy .c file
