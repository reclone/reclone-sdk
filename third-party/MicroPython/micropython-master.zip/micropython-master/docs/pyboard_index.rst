MicroPython documentation and references
========================================

.. toctree::

    pyboard/quickref.rst
    pyboard/general.rst
    pyboard/tutorial/index.rst
    library/index.rst
    pyboard/hardware/index.rst
    license.rst
    pyboard_contents.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
